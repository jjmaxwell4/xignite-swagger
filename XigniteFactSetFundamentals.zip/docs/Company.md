# Company

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**symbol** | **str** |  | [optional] 
**cik** | **str** |  | [optional] 
**cusip** | **str** |  | [optional] 
**sedol** | **str** |  | [optional] 
**isin** | **str** |  | [optional] 
**fact_set_security_id** | **str** |  | [optional] 
**fact_set_issuer_id** | **str** |  | [optional] 
**valoren** | **str** |  | [optional] 
**market** | **str** |  | [optional] 
**market_identification_code** | **str** |  | [optional] 
**primary_market** | **str** |  | [optional] 
**primary_market_identification_code** | **str** |  | [optional] 
**sector** | **str** |  | [optional] 
**industry** | **str** |  | [optional] 
**statement_template** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

