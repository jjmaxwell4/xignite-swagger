# Fundamental

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**outcome** | **str** |  | [optional] 
**message** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**report_type** | **str** |  | [optional] 
**is_restated** | **bool** |  | [optional] 
**value** | **str** |  | [optional] 
**_date** | **str** |  | [optional] 
**last_updated** | **str** |  | [optional] 
**unit** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

