# ExchangeDescription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**market_identification_code** | **str** |  | [optional] 
**market** | **str** |  | [optional] 
**region** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

