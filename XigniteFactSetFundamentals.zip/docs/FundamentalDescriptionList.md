# FundamentalDescriptionList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fundamental_descriptions** | [**list[FundamentalDescription]**](FundamentalDescription.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

